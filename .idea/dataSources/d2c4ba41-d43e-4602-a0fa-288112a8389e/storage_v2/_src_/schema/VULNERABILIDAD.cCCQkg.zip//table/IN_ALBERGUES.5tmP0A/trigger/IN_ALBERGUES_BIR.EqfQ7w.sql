create trigger IN_ALBERGUES_BIR
  before insert
  on IN_ALBERGUES
  for each row
  BEGIN
  SELECT IN_ALBERGUES_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

