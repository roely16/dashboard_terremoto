create trigger CAT_DEPENDENCIAS_BIR
  before insert
  on CAT_DEPENDENCIAS
  for each row
  BEGIN
  SELECT CAT_DEPENDENCIAS_SEQ.NEXTVAL
  INTO   :new.ID_DEPENDENCIA
  FROM   dual;
END;
/

