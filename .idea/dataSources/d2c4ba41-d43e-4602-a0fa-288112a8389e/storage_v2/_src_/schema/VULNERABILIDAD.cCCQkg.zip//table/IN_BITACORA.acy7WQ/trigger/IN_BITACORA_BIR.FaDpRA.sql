create trigger IN_BITACORA_BIR
  before insert
  on IN_BITACORA
  for each row
  BEGIN
  SELECT IN_BITACORA_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

