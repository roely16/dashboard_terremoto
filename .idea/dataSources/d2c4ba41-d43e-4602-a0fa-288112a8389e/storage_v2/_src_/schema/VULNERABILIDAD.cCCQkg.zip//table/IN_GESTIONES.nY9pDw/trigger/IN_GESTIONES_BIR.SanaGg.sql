create trigger IN_GESTIONES_BIR
  before insert
  on IN_GESTIONES
  for each row
  BEGIN
  SELECT IN_GESTIONES_SEQ.NEXTVAL
  INTO   :new.id_gestion
  FROM   dual;
END;
/

