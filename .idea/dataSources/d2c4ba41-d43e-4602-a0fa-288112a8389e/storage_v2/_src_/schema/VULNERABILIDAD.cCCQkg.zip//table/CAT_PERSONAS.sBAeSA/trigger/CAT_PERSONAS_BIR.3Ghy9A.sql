create trigger CAT_PERSONAS_BIR
  before insert
  on CAT_PERSONAS
  for each row
  BEGIN
  SELECT CAT_PERSONAS_SEQ.NEXTVAL
  INTO   :new.ID_PERSONA
  FROM   dual;
END;
/

