create trigger CAT_ALBERGUES_BIR
  before insert
  on CAT_ALBERGUES
  for each row
  BEGIN
  SELECT CAT_ALBERGUES_SEQ.NEXTVAL
  INTO   :new.ID_ALBERGUE
  FROM   dual;
END;
/

