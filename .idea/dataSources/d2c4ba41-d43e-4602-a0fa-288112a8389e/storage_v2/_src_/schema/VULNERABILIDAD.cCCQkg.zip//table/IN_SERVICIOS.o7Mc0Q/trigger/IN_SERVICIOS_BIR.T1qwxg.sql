create trigger IN_SERVICIOS_BIR
  before insert
  on IN_SERVICIOS
  for each row
  BEGIN
  SELECT IN_SERVICIOS_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

