create trigger CAT_DANIOS_BIR
  before insert
  on CAT_DANIOS
  for each row
  BEGIN
  SELECT CAT_DANIOS_SEQ.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

