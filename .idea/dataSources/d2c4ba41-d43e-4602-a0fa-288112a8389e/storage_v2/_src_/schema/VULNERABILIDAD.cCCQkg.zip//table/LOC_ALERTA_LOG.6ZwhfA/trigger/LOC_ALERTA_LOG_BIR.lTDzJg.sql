create trigger LOC_ALERTA_LOG_BIR
  before insert
  on LOC_ALERTA_LOG
  for each row
  BEGIN
  SELECT LOC_ALERTA_LOG_SEQ .NEXTVAL
  INTO   :new.ID_LOG
  FROM   dual;
END;
/

