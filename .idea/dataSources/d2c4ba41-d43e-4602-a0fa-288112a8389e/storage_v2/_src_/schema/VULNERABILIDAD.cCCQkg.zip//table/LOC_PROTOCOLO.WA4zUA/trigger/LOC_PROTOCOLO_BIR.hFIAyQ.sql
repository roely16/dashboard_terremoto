create trigger LOC_PROTOCOLO_BIR
  before insert
  on LOC_PROTOCOLO
  for each row
  BEGIN
  SELECT LOC_PROTOCOLO_SEQ.NEXTVAL
  INTO   :new.ID_PROTOCOLO
  FROM   dual;
END;
/

