create trigger CAT_ALERTAS_BIR
  before insert
  on CAT_ALERTAS
  for each row
  BEGIN
  SELECT CAT_ALERTAS_SEQ.NEXTVAL
  INTO   :new.ID_ALERTA
  FROM   dual;
END;
/

