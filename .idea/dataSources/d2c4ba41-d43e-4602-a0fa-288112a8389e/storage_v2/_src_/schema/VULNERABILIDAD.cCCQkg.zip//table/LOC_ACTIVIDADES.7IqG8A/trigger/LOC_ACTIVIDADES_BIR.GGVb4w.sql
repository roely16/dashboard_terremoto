create trigger LOC_ACTIVIDADES_BIR
  before insert
  on LOC_ACTIVIDADES
  for each row
  BEGIN
  SELECT LOC_ACTIVIDADES_SEQ.NEXTVAL
  INTO   :new.ID_ACTIVIDAD
  FROM   dual;
END;
/

