create trigger LOC_ORGANIZACION_BIR
  before insert
  on LOC_ORGANIZACION
  for each row
  BEGIN
  SELECT LOC_ORGANIZACION_SEQ.NEXTVAL
  INTO   :new.ID_ORGANIZACION
  FROM   dual;
END;
/

