create trigger IN_DANIOS_BIR
  before insert
  on IN_DANIOS
  for each row
  BEGIN
  SELECT IN_DANIOS_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

