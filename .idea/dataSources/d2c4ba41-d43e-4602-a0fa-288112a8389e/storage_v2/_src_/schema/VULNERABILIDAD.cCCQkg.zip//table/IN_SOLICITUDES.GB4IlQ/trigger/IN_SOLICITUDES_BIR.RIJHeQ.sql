create trigger IN_SOLICITUDES_BIR
  before insert
  on IN_SOLICITUDES
  for each row
  BEGIN
  SELECT IN_SOLICITUDES_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

