create trigger LOC_MENSAJE_BIR
  before insert
  on LOC_MENSAJE
  for each row
  BEGIN
  SELECT LOC_MENSAJE_SEQ.NEXTVAL
  INTO   :new.ID_MENSAJE
  FROM   dual;
END;
/

