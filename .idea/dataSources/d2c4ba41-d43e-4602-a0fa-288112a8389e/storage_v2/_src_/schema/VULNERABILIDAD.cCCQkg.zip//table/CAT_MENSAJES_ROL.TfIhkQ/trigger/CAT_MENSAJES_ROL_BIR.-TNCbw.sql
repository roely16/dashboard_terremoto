create trigger CAT_MENSAJES_ROL_BIR
  before insert
  on CAT_MENSAJES_ROL
  for each row
  BEGIN
  SELECT CAT_MENSAJES_ROL_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

