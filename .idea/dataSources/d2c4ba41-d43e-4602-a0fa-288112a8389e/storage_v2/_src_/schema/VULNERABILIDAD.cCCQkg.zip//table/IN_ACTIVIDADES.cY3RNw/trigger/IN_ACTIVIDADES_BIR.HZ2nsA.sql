create trigger IN_ACTIVIDADES_BIR
  before insert
  on IN_ACTIVIDADES
  for each row
  BEGIN
  SELECT IN_ACTIVIDADES_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

