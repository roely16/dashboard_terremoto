create trigger IN_INCIDENTES_BIR
  before insert
  on IN_INCIDENTES
  for each row
  BEGIN
  SELECT IN_INCIDENTES_SEQ.NEXTVAL
  INTO   :new.ID_INCIDENTE
  FROM   dual;
END;
/

