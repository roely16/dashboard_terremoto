create trigger CAT_PROTOCOLOS_BIR
  before insert
  on CAT_PROTOCOLOS
  for each row
  BEGIN
  SELECT CAT_PROTOCOLOS_SEQ.NEXTVAL
  INTO   :new.ID_PROTOCOLO
  FROM   dual;
END;
/

