create FUNCTION Desencriptar(Cadena in varchar2) RETURN varchar2 IS
   NewWord Varchar2(50) := null;
Begin
  For Counter IN 1..Length(Cadena) Loop
      If MOD(Counter,2) = 0 Then
         NewWord := NewWord || CHR(ASCII(SUBSTR(Cadena, Counter))-1);
      Else
         NewWord := NewWord || CHR(ASCII(SUBSTR(Cadena, Counter))+1);
      End If;
  End Loop;
  Return (rtrim(NewWord));
End;
/

