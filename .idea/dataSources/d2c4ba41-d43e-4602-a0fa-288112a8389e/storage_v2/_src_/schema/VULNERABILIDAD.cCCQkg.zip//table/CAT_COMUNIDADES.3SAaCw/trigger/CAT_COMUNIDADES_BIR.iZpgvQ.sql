create trigger CAT_COMUNIDADES_BIR
  before insert
  on CAT_COMUNIDADES
  for each row
  BEGIN
  SELECT CAT_COMUNIDADES_SEQ.NEXTVAL
  INTO   :new.ID_COMUNIDAD
  FROM   dual;
END;
/

