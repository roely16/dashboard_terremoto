create trigger CAT_ACTIVIDADES_BIR
  before insert
  on CAT_ACTIVIDADES
  for each row
  BEGIN
  SELECT CAT_ACTIVIDADES_SEQ.NEXTVAL
  INTO   :new.ID_ACTIVIDAD
  FROM   dual;
END;
/

