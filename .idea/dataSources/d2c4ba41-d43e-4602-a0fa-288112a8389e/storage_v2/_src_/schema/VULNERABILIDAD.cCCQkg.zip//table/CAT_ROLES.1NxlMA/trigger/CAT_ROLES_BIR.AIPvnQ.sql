create trigger CAT_ROLES_BIR
  before insert
  on CAT_ROLES
  for each row
  BEGIN
  SELECT CAT_ROLES_SEQ.NEXTVAL
  INTO   :new.ID_ROL
  FROM   dual;
END;
/

