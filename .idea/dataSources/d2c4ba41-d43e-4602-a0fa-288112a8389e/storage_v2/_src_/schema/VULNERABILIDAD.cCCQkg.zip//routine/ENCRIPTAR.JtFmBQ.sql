create FUNCTION Encriptar(Cadena in varchar2) RETURN Varchar2 IS
   NewWord Varchar2(30) := null;
Begin
   For Counter IN 1..Length(Cadena) Loop
       If MOD(Counter,2) = 0 Then
            NewWord := NewWord || CHR(ASCII(SUBSTR(Cadena,Counter))+1);
        Else
            NewWord := NewWord || CHR(ASCII(SUBSTR(Cadena,Counter))-1);
        End If;
   End Loop;
 Return(rTrim(NewWord));
End;
/

