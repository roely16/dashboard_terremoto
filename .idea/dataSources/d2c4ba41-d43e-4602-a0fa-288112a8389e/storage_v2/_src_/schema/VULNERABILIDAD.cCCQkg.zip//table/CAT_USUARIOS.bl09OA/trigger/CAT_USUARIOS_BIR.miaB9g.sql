create trigger CAT_USUARIOS_BIR
  before insert
  on CAT_USUARIOS
  for each row
  BEGIN
  SELECT CAT_USUARIOS_SEQ.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

