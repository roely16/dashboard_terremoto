create trigger LOC_PERSONA_BIR
  before insert
  on LOC_PERSONA
  for each row
  BEGIN
  SELECT LOC_PERSONA_SEQ.NEXTVAL
  INTO   :new.ID_PERSONA
  FROM   dual;
END;
/

