create trigger IN_ALERTAS_BIR
  before insert
  on IN_ALERTAS
  for each row
  BEGIN
  SELECT IN_ALERTAS_SEQ.NEXTVAL
  INTO   :new.ID_CORRELATIVO
  FROM   dual;
END;
/

