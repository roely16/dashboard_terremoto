create trigger CAT_CATEGORIAS_BIR
  before insert
  on CAT_CATEGORIAS
  for each row
  BEGIN
  SELECT CAT_CATEGORIAS_SEQ.NEXTVAL
  INTO   :new.ID_CATEGORIA
  FROM   dual;
END;
/

