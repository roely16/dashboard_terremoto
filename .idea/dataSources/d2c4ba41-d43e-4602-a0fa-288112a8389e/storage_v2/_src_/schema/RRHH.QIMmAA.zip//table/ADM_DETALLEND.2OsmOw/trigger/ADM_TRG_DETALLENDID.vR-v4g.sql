create trigger ADM_TRG_DETALLENDID
  before insert
  on ADM_DETALLEND
  for each row
  BEGIN
  SELECT SEQ_detallendid.NEXTVAL
  INTO   :new.detallendid
  FROM   dual;
END;
/

