create FUNCTION      ENVIAR_CORREO_MANTENIMIENTO(numero NUMBER) RETURN varchar2 IS
  v_debug_mode        BOOLEAN := TRUE;
  v_req               utl_http.req;
  v_resp              utl_http.resp;
  v_msg               VARCHAR2(80);
  v_entire_msg        VARCHAR2(32767) := NULL;
  v_conversion_factor NUMBER;
  v_url               VARCHAR2(256) := 'http://172.23.25.31/administrativo/control_vehiculos/routes/mail/enviar.php';
BEGIN
  v_req := utl_http.begin_request(url => v_url,
     method => 'GET');
  v_resp := utl_http.get_response(r => v_req);
 

  IF    v_debug_mode
  THEN 
     dbms_output.put_line('HTTP Status Return code: '||
                     v_resp.status_code);
  END IF;
 

  BEGIN
     LOOP
       utl_http.read_text(r => v_resp,data => v_msg);
       v_entire_msg := v_entire_msg||v_msg;
     END LOOP;
  EXCEPTION
     WHEN  utl_http.end_of_body
     THEN  null;
  END;

  --clean up the data received by the webservice
  v_entire_msg := REPLACE(v_entire_msg, chr(13));
  v_entire_msg := REPLACE(v_entire_msg, chr(10));
  v_entire_msg := REPLACE(v_entire_msg,
     '<?xml version="1.0" encoding="utf-8"?>');
  v_entire_msg := REPLACE(v_entire_msg,
     '<double xmlns="http://www.webservicex.net/">');
  v_entire_msg := REPLACE(v_entire_msg, '</double>');
 
  IF    v_debug_mode
  THEN  dbms_output.put_line(v_entire_msg);
  END IF;

  utl_http.end_response(r => v_resp);

  RETURN v_entire_msg;

EXCEPTION
  WHEN  others
  THEN  RETURN NULL;
END;
/

