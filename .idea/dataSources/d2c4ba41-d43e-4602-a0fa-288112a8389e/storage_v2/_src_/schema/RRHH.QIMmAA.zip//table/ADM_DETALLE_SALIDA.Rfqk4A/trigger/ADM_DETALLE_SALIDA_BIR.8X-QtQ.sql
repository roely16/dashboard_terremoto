create trigger ADM_DETALLE_SALIDA_BIR
  before insert
  on ADM_DETALLE_SALIDA
  for each row
  BEGIN 
    SELECT     ADM_DETALLE_SALIDA_SQ.NEXTVAL
    INTO     :new.DETALLEID
    FROM     dual;
END;
/

