create trigger ADM_TRG_DETALLEORDENID
  before insert
  on ADM_DETALLEORDEN
  for each row
  BEGIN
  SELECT SEQ_detalleid.NEXTVAL
  INTO   :new.detalleordenid
  FROM   dual;
END;
/

