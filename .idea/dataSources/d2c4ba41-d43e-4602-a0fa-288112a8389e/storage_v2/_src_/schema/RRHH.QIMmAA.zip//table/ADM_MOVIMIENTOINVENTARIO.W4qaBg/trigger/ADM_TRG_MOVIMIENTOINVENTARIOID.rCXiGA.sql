create trigger ADM_TRG_MOVIMIENTOINVENTARIOID
  before insert
  on ADM_MOVIMIENTOINVENTARIO
  for each row
  BEGIN
  SELECT SEQ_movimientoinventarioid.NEXTVAL
  INTO   :new.movimientoinventarioid
  FROM   dual;
END;
/

