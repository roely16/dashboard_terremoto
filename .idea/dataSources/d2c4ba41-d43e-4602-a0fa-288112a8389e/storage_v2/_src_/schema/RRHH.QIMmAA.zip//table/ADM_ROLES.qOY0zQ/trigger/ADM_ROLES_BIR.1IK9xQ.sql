create trigger ADM_ROLES_BIR
  before insert
  on ADM_ROLES
  for each row
  BEGIN
  SELECT  ADM_ROLES_SEQ.NEXTVAL
  INTO    :new.ROLID
  FROM    dual;
END;
/

