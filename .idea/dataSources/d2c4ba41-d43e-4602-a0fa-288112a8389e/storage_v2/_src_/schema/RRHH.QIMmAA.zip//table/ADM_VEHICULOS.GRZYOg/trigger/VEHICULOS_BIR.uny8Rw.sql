create trigger VEHICULOS_BIR
  before insert
  on ADM_VEHICULOS
  for each row
  BEGIN
  SELECT vehiculos_seq.NEXTVAL
  INTO   :new.VEHICULOID
  FROM   dual;
END;
/

