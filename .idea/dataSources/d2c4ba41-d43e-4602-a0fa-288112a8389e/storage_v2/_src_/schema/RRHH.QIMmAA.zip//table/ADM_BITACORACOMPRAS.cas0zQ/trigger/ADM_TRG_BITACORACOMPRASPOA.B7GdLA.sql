create trigger ADM_TRG_BITACORACOMPRASPOA
  before insert
  on ADM_BITACORACOMPRAS
  for each row
  BEGIN
  SELECT SEQ_bitacoracompraspoa.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

