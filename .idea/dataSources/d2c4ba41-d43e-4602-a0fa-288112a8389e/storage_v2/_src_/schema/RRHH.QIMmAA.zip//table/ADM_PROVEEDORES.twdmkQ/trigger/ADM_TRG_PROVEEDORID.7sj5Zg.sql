create trigger ADM_TRG_PROVEEDORID
  before insert
  on ADM_PROVEEDORES
  for each row
  BEGIN
  SELECT SEQ_proveedorid.NEXTVAL
  INTO   :new.proveedorid
  FROM   dual;
END;
/

