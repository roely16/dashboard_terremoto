create trigger ADM_TIPO_DETALLE_SALIDA_BIR
  before insert
  on ADM_TIPO_DETALLE_SALIDA
  for each row
  BEGIN 
    SELECT    ADM_TIPO_DETALLE_SALIDA_SQ.NEXTVAL
    INTO     :new.TIPO_DETALLE_SALIDA_ID
    FROM    dual;
END;
/

