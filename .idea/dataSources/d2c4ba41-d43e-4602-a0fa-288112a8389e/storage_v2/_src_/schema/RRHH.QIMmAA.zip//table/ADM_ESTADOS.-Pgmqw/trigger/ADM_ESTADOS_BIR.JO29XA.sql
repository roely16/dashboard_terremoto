create trigger ADM_ESTADOS_BIR
  before insert
  on ADM_ESTADOS
  for each row
  BEGIN
  SELECT ADM_ESTADOS_SEQ.NEXTVAL
  INTO   :new.ESTADOID
  FROM   dual;
END;
/

