create trigger ADM_TRG_COTICARRETILLAID
  before insert
  on ADM_CARRETILLACOTI
  for each row
  BEGIN
  SELECT SEQ_coticarretillaid.NEXTVAL
  INTO   :new.carretillaid
  FROM   dual;
END;
/

