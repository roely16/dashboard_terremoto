create trigger ADM_TRG_BITACORAGESTID
  before insert
  on ADM_BITACORAGEST
  for each row
  BEGIN
  SELECT SEQ_gest_bitacoraid.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

