create trigger ADM_TRG_CARRETILLAID
  before insert
  on ADM_CARRETILLA
  for each row
  BEGIN
  SELECT SEQ_carretillaid.NEXTVAL
  INTO   :new.carretillaid
  FROM   dual;
END;
/

