create trigger EQP_TRG_SOLICITUDIDBAJA
  before insert
  on EQP_SOLICITUDESBAJA
  for each row
  BEGIN
  SELECT SEQ_solicitudidbaja.NEXTVAL
  INTO   :new.solicitudid
  FROM   dual;
END;
/

