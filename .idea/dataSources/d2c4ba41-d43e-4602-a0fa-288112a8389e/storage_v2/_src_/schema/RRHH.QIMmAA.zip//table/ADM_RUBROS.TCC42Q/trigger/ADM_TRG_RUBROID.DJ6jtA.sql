create trigger ADM_TRG_RUBROID
  before insert
  on ADM_RUBROS
  for each row
  BEGIN
  SELECT SEQ_rubroid.NEXTVAL
  INTO   :new.rubroid
  FROM   dual;
END;
/

