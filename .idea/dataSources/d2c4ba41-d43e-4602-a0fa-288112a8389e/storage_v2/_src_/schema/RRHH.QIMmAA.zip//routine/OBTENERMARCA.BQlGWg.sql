create FUNCTION      ObtenerMarca(Cadena in number) RETURN varchar2 IS
   NewWord Varchar2(150) := null;
Begin
 
  select
  nombre into NewWord from eqp_marcas where marcaid = Cadena;
  
  Return (rtrim(NewWord));
End;
/

