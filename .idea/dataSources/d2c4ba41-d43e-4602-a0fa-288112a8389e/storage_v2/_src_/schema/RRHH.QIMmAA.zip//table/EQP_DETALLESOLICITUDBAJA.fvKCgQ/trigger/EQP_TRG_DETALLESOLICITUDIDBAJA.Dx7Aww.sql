create trigger EQP_TRG_DETALLESOLICITUDIDBAJA
  before insert
  on EQP_DETALLESOLICITUDBAJA
  for each row
  BEGIN
  SELECT SEQ_EQP_detallesolicitudidbaja.NEXTVAL
  INTO   :new.detallesolicitudid
  FROM   dual;
END;
/

