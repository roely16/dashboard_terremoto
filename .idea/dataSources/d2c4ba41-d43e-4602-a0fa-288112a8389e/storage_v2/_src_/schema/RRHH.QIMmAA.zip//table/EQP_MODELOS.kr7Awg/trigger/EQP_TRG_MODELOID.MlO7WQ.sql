create trigger EQP_TRG_MODELOID
  before insert
  on EQP_MODELOS
  for each row
  BEGIN
  SELECT SEQ_eqp_modeloid.NEXTVAL
  INTO   :new.modeloid
  FROM   dual;
END;
/

