create trigger ADM_TRG_BITACORAIDTID
  before insert
  on ADM_BITACORACOTIZACION
  for each row
  BEGIN
  SELECT SEQ_cotibitacoraid.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

