create trigger RH_TRG_JUSTIFICACIONID
  before insert
  on RH_JUSTIFICACIONES
  for each row
  BEGIN
  SELECT RH_JUSTIFICACIONES_SEQ.NEXTVAL
  INTO   :new.justificacionid
  FROM   dual;
END;
/

