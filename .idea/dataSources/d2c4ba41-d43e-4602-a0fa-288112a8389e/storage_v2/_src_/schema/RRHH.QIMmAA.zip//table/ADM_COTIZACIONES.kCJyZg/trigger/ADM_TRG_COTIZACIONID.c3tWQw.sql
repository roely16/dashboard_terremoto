create trigger ADM_TRG_COTIZACIONID
  before insert
  on ADM_COTIZACIONES
  for each row
  BEGIN
  SELECT SEQ_cotizacionid.NEXTVAL
  INTO   :new.cotizacionid
  FROM   dual;
END;
/

