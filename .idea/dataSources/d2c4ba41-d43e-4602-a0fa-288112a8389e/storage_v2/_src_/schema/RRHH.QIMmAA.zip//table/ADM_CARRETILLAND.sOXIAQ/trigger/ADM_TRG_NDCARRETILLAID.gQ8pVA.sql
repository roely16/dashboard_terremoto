create trigger ADM_TRG_NDCARRETILLAID
  before insert
  on ADM_CARRETILLAND
  for each row
  BEGIN
  SELECT SEQ_ndcarretillaid.NEXTVAL
  INTO   :new.carretillaid
  FROM   dual;
END;
/

