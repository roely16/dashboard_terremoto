create trigger RH_TRG_ASUETO_ID
  before insert
  on RH_ASUETOS
  for each row
  BEGIN
  SELECT RH_ASUETOS_SEQ.NEXTVAL
  INTO   :new.ASUETO_ID
  FROM   dual;
END;
/

