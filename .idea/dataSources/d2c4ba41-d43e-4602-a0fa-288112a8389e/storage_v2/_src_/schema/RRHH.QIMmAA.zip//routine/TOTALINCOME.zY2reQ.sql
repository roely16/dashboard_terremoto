create Function TotalIncome
  
   RETURN varchar2
IS
   total_val varchar(100);

   cursor c1 is
     SELECT FECHA_INICIO
     FROM ADM_TEMP_SEMANAS
     ORDER BY FECHA_INICIO ASC;

BEGIN

    

   FOR employee_rec in c1
   LOOP
      total_val := employee_rec.FECHA_INICIO;
   END LOOP;

   RETURN total_val;

END;
/

