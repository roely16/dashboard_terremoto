create trigger EQP_INVENTARIO_TEMP_ID
  before insert
  on EQP_INVENTARIO_TEMP
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       EQP_INVENTARIO_TEMP_ID
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        17/11/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     EQP_INVENTARIO_TEMP_ID
      Sysdate:         17/11/2017
      Date and Time:   17/11/2017, 10:57:10, and 17/11/2017 10:57:10
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      EQP_INVENTARIO_TEMP (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT CORR_INVENTARIO_TEMP.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ACTIVOID := tmpVar;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END EQP_INVENTARIO_TEMP_ID;
/

