create view MSA_EXPEDIENTES_VW as
  SELECT 
        5 ID_MEDICION, 
        A.FECHA FECHA_SERVICIO, 
        USUARIO COLABORADOR, 
        a.nombre CLIENTE, 
        DECODE(a.num_wf_documento, NULL, 'IUSI CASO', C.DESCRIPCION)||'-'||DECODE(a.num_wf_documento, NULL, a.num_iusicaso, ('WF-'||a.num_wf_documento||'-'||a.num_wf_anio)) DOC_REFERENCIA, 
        A.TELEFONO CONTACTO, 
        EXTRACT(year from A.FECHA) as anio, 
        a.num_wf_documento DOCUMENTO, 
        A.NUM_WF_ANIO ANIO_DOC,
        A.ID_INGRESO_EXPEDIENTE
  FROM 
            catastro.aav_ingreso_expediente a
            ,cdo_tramite b
            ,CDO_CLASEDOCTO C 
  WHERE a.cod_tramite = b.codtramite AND A.WF_CODIGOCLASE = C.CODIGOCLASE
/

