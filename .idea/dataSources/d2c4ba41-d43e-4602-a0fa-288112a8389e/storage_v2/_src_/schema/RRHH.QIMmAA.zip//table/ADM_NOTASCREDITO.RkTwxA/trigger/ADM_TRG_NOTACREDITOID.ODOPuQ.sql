create trigger ADM_TRG_NOTACREDITOID
  before insert
  on ADM_NOTASCREDITO
  for each row
  BEGIN
  SELECT SEQ_notacreditoid.NEXTVAL
  INTO   :new.notacreditoid
  FROM   dual;
END;
/

