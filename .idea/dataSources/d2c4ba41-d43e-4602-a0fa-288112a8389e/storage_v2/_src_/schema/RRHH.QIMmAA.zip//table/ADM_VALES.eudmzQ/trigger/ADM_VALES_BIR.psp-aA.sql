create trigger ADM_VALES_BIR
  before insert
  on ADM_VALES
  for each row
  BEGIN
  SELECT ADM_VALES_SEQ.NEXTVAL
  INTO   :new.VALEID
  FROM   dual;
END;
/

