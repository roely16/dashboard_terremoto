create trigger ADM_TRG_PRODUCTOID
  before insert
  on ADM_PRODUCTOS
  for each row
  BEGIN
  SELECT SEQ_productoid.NEXTVAL
  INTO   :new.productoid
  FROM   dual;
END;
/

