create trigger ADM_CUOTAS_BIR
  before insert
  on ADM_CUOTAS_COMBUSTIBLE
  for each row
  BEGIN
  SELECT  ADM_CUOTAS_COMBUSTIBLE_SEQ.NEXTVAL
  INTO    :new.CUOTAID
  FROM    dual;
END;
/

