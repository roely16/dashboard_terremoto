create trigger ADM_TRG_ENCUESTAID
  before insert
  on ADM_ENCUESTA
  for each row
  BEGIN
  SELECT SEQ_encuestaid.NEXTVAL
  INTO   :new.encuestaid
  FROM   dual;
END;
/

