create trigger ADM_TRG_DETALLECOTIZACIONID
  before insert
  on ADM_DETALLECOTIZACION
  for each row
  BEGIN
  SELECT SEQ_detallecotizacionid.NEXTVAL
  INTO   :new.detallecotizacionid
  FROM   dual;
END;
/

