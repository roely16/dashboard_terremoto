create trigger EQP_BITACORA_VERIFICACION
  before insert
  on EQP_SOLICITUDBITACORA
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        20/09/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     
      Sysdate:         20/09/2017
      Date and Time:   20/09/2017, 11:31:20, and 20/09/2017 11:31:20
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      EQP_SOLICITUDBITACORA (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT CORR_EQPBITACORA.NEXTVAL INTO tmpVar FROM dual;
   :NEW.BITACORAID := tmpVar;


   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END ;
/

