create trigger ADM_TRG_DEVOLUCIONID
  before insert
  on ADM_DEVOLUCIONES
  for each row
  BEGIN
  SELECT SEQ_devolucionid.NEXTVAL
  INTO   :new.devolucionid
  FROM   dual;
END;
/

