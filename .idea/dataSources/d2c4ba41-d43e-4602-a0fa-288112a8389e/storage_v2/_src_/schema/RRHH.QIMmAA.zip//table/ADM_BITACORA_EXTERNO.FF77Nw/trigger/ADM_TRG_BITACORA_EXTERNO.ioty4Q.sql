create trigger ADM_TRG_BITACORA_EXTERNO
  before insert
  on ADM_BITACORA_EXTERNO
  for each row
  BEGIN
  SELECT SEQ_bitacoraid_externo.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

