create trigger EQP_TRG_INVENTARIOID
  before insert
  on EQP_INVENTARIO
  for each row
  BEGIN
  SELECT SEQ_eqp_inventarioid.NEXTVAL
  INTO   :new.inventarioid
  FROM   dual;
END;
/

