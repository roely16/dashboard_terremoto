create trigger ADM_DOCUMENTOS_BIR
  before insert
  on ADM_DOCUMENTOS
  for each row
  BEGIN
  SELECT  ADM_DOCUMENTOS_SEQ.NEXTVAL
  INTO    :new.DOCUMENTOID
  FROM    dual;
END;
/

