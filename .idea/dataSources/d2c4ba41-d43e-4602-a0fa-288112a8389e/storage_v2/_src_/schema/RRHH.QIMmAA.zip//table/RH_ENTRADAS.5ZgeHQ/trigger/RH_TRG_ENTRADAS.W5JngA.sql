create trigger RH_TRG_ENTRADAS
  before insert
  on RH_ENTRADAS
  for each row
  BEGIN
  SELECT SEQ_entradas.NEXTVAL
  INTO   :new.entradaid
  FROM   dual;
END;
/

