create trigger ADM_TRG_NCCARRETILLAID
  before insert
  on ADM_CARRETILLANC
  for each row
  BEGIN
  SELECT SEQ_nccarretillaid.NEXTVAL
  INTO   :new.carretillaid
  FROM   dual;
END;
/

