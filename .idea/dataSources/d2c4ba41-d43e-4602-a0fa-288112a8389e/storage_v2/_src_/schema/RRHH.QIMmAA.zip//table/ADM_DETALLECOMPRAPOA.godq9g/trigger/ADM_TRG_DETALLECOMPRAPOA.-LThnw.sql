create trigger ADM_TRG_DETALLECOMPRAPOA
  before insert
  on ADM_DETALLECOMPRAPOA
  for each row
  BEGIN
  SELECT SEQ_detallecomprapoa.NEXTVAL
  INTO   :new.detallecompraid
  FROM   dual;
END;
/

