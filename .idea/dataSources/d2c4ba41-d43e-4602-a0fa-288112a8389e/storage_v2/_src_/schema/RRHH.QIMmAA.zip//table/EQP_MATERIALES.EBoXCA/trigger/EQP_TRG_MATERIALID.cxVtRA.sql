create trigger EQP_TRG_MATERIALID
  before insert
  on EQP_MATERIALES
  for each row
  BEGIN
  SELECT SEQ_eqp_materialid.NEXTVAL
  INTO   :new.materialid
  FROM   dual;
END;
/

