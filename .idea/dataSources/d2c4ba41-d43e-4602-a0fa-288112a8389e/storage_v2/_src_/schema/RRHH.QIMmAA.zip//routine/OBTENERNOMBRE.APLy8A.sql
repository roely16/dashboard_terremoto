create FUNCTION      ObtenerNombre(Cadena in varchar2) RETURN varchar2 IS
   NewWord Varchar2(150) := null;
Begin
 
  select
  nombre||' '||apellido into NewWord from rh_empleados where nit = Cadena;
  
  Return (rtrim(NewWord));
End;
/

