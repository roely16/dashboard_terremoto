create FUNCTION      ObtenerStatus(Cadena in number) RETURN varchar2 IS
   NewWord Varchar2(150) := null;
Begin
 
  select
  nombre into NewWord from adm_status where statusid = Cadena;
  
  Return (rtrim(NewWord));
End;
/

