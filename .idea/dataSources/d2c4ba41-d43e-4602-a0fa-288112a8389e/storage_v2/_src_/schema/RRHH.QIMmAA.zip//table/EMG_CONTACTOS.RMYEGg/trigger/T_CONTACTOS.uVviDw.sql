create trigger T_CONTACTOS
  before insert
  on EMG_CONTACTOS
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       T_CONTACTOS
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        02/08/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     T_CONTACTOS
      Sysdate:         02/08/2017
      Date and Time:   02/08/2017, 16:08:14, and 02/08/2017 16:08:14
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      EMG_CONTACTOS (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT CORRELATIVO_CONTACTOS.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ID := tmpVar;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END T_CONTACTOS;
/

