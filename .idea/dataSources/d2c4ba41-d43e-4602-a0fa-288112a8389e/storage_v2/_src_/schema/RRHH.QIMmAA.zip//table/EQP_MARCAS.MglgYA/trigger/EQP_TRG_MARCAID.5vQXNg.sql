create trigger EQP_TRG_MARCAID
  before insert
  on EQP_MARCAS
  for each row
  BEGIN
  SELECT SEQ_eqp_marcaid.NEXTVAL
  INTO   :new.marcaid
  FROM   dual;
END;
/

