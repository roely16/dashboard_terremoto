create trigger ADM_TRG_WORKFLOWID
  before insert
  on ADM_WORKFLOW
  for each row
  BEGIN
  SELECT SEQ_workflowid.NEXTVAL
  INTO   :new.workflowid
  FROM   dual;
END;
/

