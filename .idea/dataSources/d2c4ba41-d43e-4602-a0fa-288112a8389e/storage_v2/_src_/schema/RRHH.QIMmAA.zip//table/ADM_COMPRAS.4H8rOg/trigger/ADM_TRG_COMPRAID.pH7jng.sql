create trigger ADM_TRG_COMPRAID
  before insert
  on ADM_COMPRAS
  for each row
  BEGIN
  SELECT SEQ_compraid.NEXTVAL
  INTO   :new.compraid
  FROM   dual;
END;
/

