create trigger EQP_TRG_MOVIMIENTOTRASLADOID
  before insert
  on EQP_MOVIMIENTOTRASLADOS
  for each row
  BEGIN
  SELECT SEQ_EQP_movimientotrasladoid.NEXTVAL
  INTO   :new.movimientosolicitudid
  FROM   dual;
END;
/

