create trigger RH_TRG_HORARIO
  before insert
  on RH_BITACORA_CHORARIO
  for each row
  BEGIN
  SELECT SEQ_HORARIO.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

