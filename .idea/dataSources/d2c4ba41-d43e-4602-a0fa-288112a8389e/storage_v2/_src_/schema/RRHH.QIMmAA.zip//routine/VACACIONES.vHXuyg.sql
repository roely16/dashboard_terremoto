create FUNCTION      VACACIONES(fecha_inicio IN DATE, fecha_fin IN DATE) RETURN NUMBER IS

    diasinhabiles   NUMBER := 0;
    diasreales      NUMBER := 0;
    fecha_actual    DATE;

BEGIN

    IF fecha_fin >= fecha_inicio THEN
        fecha_actual := fecha_inicio;

        WHILE fecha_actual <= fecha_fin LOOP

            IF TO_CHAR(fecha_actual,'DY') NOT IN ('SAT','SUN') then

                diasreales := diasreales + 1;

            END IF;

            fecha_actual := fecha_actual + 1;

        END LOOP;

        SELECT COUNT(FECHA)
          INTO diasinhabiles
          FROM RH_ASUETOS
         WHERE FECHA BETWEEN fecha_inicio AND fecha_fin;

        RETURN diasreales - diasinhabiles;

    ELSE

        RETURN 0;

    END IF;

END;
/

