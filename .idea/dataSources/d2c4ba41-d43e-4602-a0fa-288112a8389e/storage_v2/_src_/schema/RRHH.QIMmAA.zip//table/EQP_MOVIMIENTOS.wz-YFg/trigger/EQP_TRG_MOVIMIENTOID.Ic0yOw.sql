create trigger EQP_TRG_MOVIMIENTOID
  before insert
  on EQP_MOVIMIENTOS
  for each row
  BEGIN
  SELECT SEQ_eqp_movimientoid.NEXTVAL
  INTO   :new.movimientoid
  FROM   dual;
END;
/

