create trigger T_CORRELATIVO
  before insert
  on ENCA_MANTENIMIENTOS
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        06/06/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     
      Sysdate:         06/06/2017
      Date and Time:   06/06/2017, 12:11:59, and 06/06/2017 12:11:59
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      ENCA_MANTENIMIENTOS (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT correlativo_mantenimientos.NEXTVAL INTO tmpVar FROM dual;
   :NEW.correlativo := tmpVar;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END ;
/

