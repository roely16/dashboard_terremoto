create view GC_TOTAL_GESTIONES_PROCESO_VW as
  WITH gestiones_abiertas AS (
         SELECT id_gestion,
                SUM(CASE
                  WHEN fecha_cierre <= fecha_propuesta_cierre THEN 1
                ELSE
                  0
                END) AS tareas_atiempo
           FROM gc_responsable_accion       
          GROUP BY id_gestion       
         ),
         gestiones_finalizadas AS (
         SELECT id_gestion,
                SUM(CASE
                  WHEN estado = 'FINALIZADO' THEN 1
                ELSE
                  0
                END) AS tareas_finalizadas
           FROM gc_responsable_accion
          GROUP BY id_gestion
         )
         SELECT d.descripcion,
                COUNT(*) AS total,
                SUM(CASE
                  WHEN b.tareas_atiempo > 0 THEN 1
                ELSE
                  0
                END) AS gestiones_atiempo,
                SUM(CASE
                  WHEN c.tareas_finalizadas > 0 THEN 1
                ELSE
                  0
                END) AS gestiones_finalizadas
           FROM gc_gestion a
           JOIN gestiones_abiertas b ON a.id_gestion = b.id_gestion
           JOIN gestiones_finalizadas c ON a.id_gestion = c.id_gestion
           JOIN gc_proceso d ON a.id_proceso = d.id_proceso
          GROUP BY d.id_proceso,
                   d.descripcion
/

