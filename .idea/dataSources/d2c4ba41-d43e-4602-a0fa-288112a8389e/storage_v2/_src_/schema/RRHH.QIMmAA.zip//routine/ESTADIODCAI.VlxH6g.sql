create FUNCTION      estadioDCAI(fecha_ingreso IN DATE) RETURN VARCHAR2 IS

    dia   NUMBER := extract(day from fecha_ingreso);
    mes   NUMBER := extract(month from fecha_ingreso);
    anio  NUMBER := extract(year from fecha_ingreso);
    texto varchar2(250) := null;
    

BEGIN

    if extract(year from sysdate) > anio then
         anio := extract(year from sysdate) - anio;
    else
        anio := 0;                
    end if;
    
    if extract(month from sysdate) > mes then
        mes := extract(month from sysdate)-mes;
    else 
        anio:= anio -1;
        mes := (extract(month from sysdate) +12 )-mes ;
    end if;    

    if extract(day from sysdate) > dia then
        dia := extract(day from sysdate) - dia;
    else
        mes := mes - 1; 
        dia := dia - extract(day from sysdate);       
    end if;
    
   if anio <= 0 then 
    anio := 0;
   end if;
   
   if mes <= 0 then
    mes := 0;
   end if;
   
   if mes = 12 then
    anio := anio + 1;
    mes := 0;
   end if;
    
    texto := 'DCAI: ' || anio || ' años ' || mes || ' Meses ' || dia || ' dias.';

    return (texto);   
END;
/

