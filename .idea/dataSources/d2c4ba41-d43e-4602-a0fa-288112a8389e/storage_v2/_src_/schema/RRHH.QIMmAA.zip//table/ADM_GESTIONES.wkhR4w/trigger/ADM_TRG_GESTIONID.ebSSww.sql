create trigger ADM_TRG_GESTIONID
  before insert
  on ADM_GESTIONES
  for each row
  BEGIN
  SELECT SEQ_gestionid.NEXTVAL
  INTO   :new.gestionid
  FROM   dual;
END;
/

