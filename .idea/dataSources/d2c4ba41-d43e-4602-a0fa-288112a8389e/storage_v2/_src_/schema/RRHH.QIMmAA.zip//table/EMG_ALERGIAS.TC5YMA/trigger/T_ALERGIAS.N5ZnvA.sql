create trigger T_ALERGIAS
  before insert
  on EMG_ALERGIAS
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       T_ALERGIAS
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        02/08/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     T_ALERGIAS
      Sysdate:         02/08/2017
      Date and Time:   02/08/2017, 14:52:12, and 02/08/2017 14:52:12
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      EMG_ALERGIAS (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT CORRELATIVO_ALERGIAS.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ID := tmpVar;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END T_ALERGIAS;
/

