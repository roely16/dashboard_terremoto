create trigger ADM_TRG_DETALLEDEVOLUCIONID
  before insert
  on ADM_DETALLEDEVOLUCION
  for each row
  BEGIN
  SELECT SEQ_detalledevolucionid.NEXTVAL
  INTO   :new.detalledevolucionid
  FROM   dual;
END;
/

