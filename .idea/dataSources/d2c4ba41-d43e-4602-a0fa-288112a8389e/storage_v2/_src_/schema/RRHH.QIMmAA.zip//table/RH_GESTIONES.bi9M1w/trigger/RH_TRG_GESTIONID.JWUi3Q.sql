create trigger RH_TRG_GESTIONID
  before insert
  on RH_GESTIONES
  for each row
  BEGIN
  SELECT SEQ_rh_gestionid.NEXTVAL
  INTO   :new.gestionid
  FROM   dual;
END;
/

