create trigger ADM_TRG_NOTADEBITOID
  before insert
  on ADM_NOTASDEBITO
  for each row
  BEGIN
  SELECT SEQ_notadebitoid.NEXTVAL
  INTO   :new.notadebitoid
  FROM   dual;
END;
/

