create trigger ADM_TRG_COMPRASPOA
  before insert
  on ADM_COMPRASPOA
  for each row
  BEGIN
  SELECT SEQ_compraspoa.NEXTVAL
  INTO   :new.compraid
  FROM   dual;
END;
/

