create trigger EQP_TRG_CATALOGOID
  before insert
  on EQP_CATALOGO
  for each row
  BEGIN
  SELECT SEQ_eqp_catalogoid.NEXTVAL
  INTO   :new.catalogoid
  FROM   dual;
END;
/

