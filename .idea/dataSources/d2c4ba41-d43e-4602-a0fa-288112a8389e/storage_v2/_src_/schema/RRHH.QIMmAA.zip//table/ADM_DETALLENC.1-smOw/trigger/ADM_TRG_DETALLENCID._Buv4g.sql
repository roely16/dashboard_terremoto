create trigger ADM_TRG_DETALLENCID
  before insert
  on ADM_DETALLENC
  for each row
  BEGIN
  SELECT SEQ_detallencid.NEXTVAL
  INTO   :new.detallencid
  FROM   dual;
END;
/

