create FUNCTION             msa_calculo_muestra (V_CANTIDAD NUMBER) RETURN NUMBER IS

V_MUESTRA NUMBER;

BEGIN

  V_MUESTRA := ROUND( (V_CANTIDAD * 3.84 * .90 * .10) / (0.01 * (V_CANTIDAD - 1) + 3.84 * .90 * .10));

  -- tmpVar := 0;
   RETURN V_MUESTRA;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       NULL;-- Consider logging the error and then re-raise
       RAISE;
END msa_calculo_muestra;
/

