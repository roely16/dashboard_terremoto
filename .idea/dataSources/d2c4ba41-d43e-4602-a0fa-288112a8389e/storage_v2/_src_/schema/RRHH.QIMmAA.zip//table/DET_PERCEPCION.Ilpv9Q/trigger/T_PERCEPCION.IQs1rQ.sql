create trigger T_PERCEPCION
  before insert
  on DET_PERCEPCION
  for each row
  DECLARE
tmpVarP NUMBER;


BEGIN
   tmpVarP := 0;

   SELECT secuencia_percepcion.NEXTVAL INTO tmpVarP FROM dual;
   :NEW.id := tmpVarP;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END T_percepcion;
/

