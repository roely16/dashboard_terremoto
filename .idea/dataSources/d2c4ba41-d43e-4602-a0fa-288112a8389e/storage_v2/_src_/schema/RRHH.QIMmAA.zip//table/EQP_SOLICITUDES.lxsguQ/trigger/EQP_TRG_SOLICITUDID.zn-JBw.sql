create trigger EQP_TRG_SOLICITUDID
  before insert
  on EQP_SOLICITUDES
  for each row
  BEGIN
  SELECT SEQ_eqp_solicitudid.NEXTVAL
  INTO   :new.solicitudid
  FROM   dual;
END;
/

