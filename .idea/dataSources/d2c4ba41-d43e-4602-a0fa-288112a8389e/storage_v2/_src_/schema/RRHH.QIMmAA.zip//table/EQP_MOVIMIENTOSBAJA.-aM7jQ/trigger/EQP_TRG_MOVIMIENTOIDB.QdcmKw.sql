create trigger EQP_TRG_MOVIMIENTOIDB
  before insert
  on EQP_MOVIMIENTOSBAJA
  for each row
  BEGIN
  SELECT SEQ_eqp_movimientoidbaja.NEXTVAL
  INTO   :new.movimientoid
  FROM   dual;
END;
/

