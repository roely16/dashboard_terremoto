create trigger EQP_SOLICITUD_VERIFICACION
  before insert
  on EQP_SOLICITUDVERIFICACION
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       EQP_SOLICITUD_VERIFICACION
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        12/09/2017             1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     EQP_SOLICITUD_VERIFICACION
      Sysdate:         12/09/2017
      Date and Time:   12/09/2017, 15:37:19, and 12/09/2017 15:37:19
      Username:         (set in TOAD Options, Proc Templates)
      Table Name:      EQP_SOLICITUDVERIFICACION (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   SELECT CORR_EQPVERIFICACION.NEXTVAL INTO tmpVar FROM dual;
   :NEW.SOLICITUDID := tmpVar;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END EQP_SOLICITUD_VERIFICACION;
/

