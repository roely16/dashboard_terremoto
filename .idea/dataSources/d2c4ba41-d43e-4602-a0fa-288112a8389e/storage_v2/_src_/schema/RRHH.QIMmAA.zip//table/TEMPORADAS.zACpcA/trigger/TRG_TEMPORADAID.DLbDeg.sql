create trigger TRG_TEMPORADAID
  before insert
  on TEMPORADAS
  for each row
  BEGIN
  SELECT SEQ_TEMPORADAID.NEXTVAL
  INTO   :new.TEMPORADAID
  FROM   dual;
END;
/

