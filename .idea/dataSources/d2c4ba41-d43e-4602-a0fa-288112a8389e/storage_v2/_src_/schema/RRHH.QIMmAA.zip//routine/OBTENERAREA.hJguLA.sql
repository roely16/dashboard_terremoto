create FUNCTION      ObtenerArea(Cadena in number) RETURN varchar2 IS
   NewWord Varchar2(150) := null;
Begin
 
  select
  descripcion into NewWord from rh_areas where codarea = Cadena;
  
  Return (rtrim(NewWord));
End;
/

