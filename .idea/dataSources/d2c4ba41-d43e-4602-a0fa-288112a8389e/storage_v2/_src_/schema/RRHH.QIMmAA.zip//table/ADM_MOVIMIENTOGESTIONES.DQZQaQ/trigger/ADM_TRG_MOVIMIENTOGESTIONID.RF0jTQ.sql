create trigger ADM_TRG_MOVIMIENTOGESTIONID
  before insert
  on ADM_MOVIMIENTOGESTIONES
  for each row
  BEGIN
  SELECT SEQ_movimientogestionid.NEXTVAL
  INTO   :new.movimientogestionid
  FROM   dual;
END;
/

