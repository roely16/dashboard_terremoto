create trigger T_TECNICO
  before insert
  on DET_TECNICO
  for each row
  DECLARE
tmpVarT NUMBER;

BEGIN
   tmpVarT := 0;

   SELECT secuencia_tecnica.NEXTVAL INTO tmpVarT FROM dual;
   :NEW.id := tmpVarT;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END t_tecnico;
/

