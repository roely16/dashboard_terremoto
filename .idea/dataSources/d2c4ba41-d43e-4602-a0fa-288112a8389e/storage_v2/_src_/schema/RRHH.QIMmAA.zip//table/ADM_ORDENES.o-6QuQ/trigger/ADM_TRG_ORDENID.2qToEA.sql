create trigger ADM_TRG_ORDENID
  before insert
  on ADM_ORDENES
  for each row
  BEGIN
  SELECT SEQ_ordenid.NEXTVAL
  INTO   :new.ordenid
  FROM   dual;
END;
/

