create trigger ADM_TRG_DETALLECOMPRAID
  before insert
  on ADM_DETALLECOMPRA
  for each row
  BEGIN
  SELECT SEQ_detallecompraid.NEXTVAL
  INTO   :new.detallecompraid
  FROM   dual;
END;
/

