create trigger RH_TRG_BITACORAGESTID
  before insert
  on RH_BITACORAGEST
  for each row
  BEGIN
  SELECT SEQ_rh_bitacoraid.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

