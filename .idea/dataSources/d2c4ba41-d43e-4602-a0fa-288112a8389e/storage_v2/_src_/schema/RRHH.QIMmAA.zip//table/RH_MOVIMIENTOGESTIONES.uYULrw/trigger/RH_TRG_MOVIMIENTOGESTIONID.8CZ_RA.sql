create trigger RH_TRG_MOVIMIENTOGESTIONID
  before insert
  on RH_MOVIMIENTOGESTIONES
  for each row
  BEGIN
  SELECT SEQ_rh_movimientogestioid.NEXTVAL
  INTO   :new.movimientogestionid
  FROM   dual;
END;
/

