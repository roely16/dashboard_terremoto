create trigger ADM_TRG_BITACORAID
  before insert
  on ADM_BITACORA
  for each row
  BEGIN
  SELECT SEQ_bitacoraid.NEXTVAL
  INTO   :new.bitacoraid
  FROM   dual;
END;
/

